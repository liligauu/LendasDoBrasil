#pragma once

#include "Inimigo.h"

//======================================================
// Classe: Lobisomem
// Inimigo escalável por fase
//======================================================

class Lobisomem : public Inimigo
{
public:

    Lobisomem(int fase);

    void atacar(Personagem& alvo) override;

    void usarHabilidade() override;
};