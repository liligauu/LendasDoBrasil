#include "Inimigo.h"

#include <iostream>
#include <cstdlib>

using namespace std;

//======================================================
// CONSTRUTORES
//======================================================

Inimigo::Inimigo()
    : Personagem(),
      chanceEsquiva(10)
{
}

Inimigo::Inimigo(string nome, int nivel, int vidaMaxima, int ataque, int defesa)
    : Personagem(nome, nivel, vidaMaxima, ataque, defesa),
      chanceEsquiva(10)
{
}

//======================================================
// DESTRUTOR
//======================================================

Inimigo::~Inimigo()
{
    cout << nome << " foi derrotado e desapareceu." << endl;
}

//======================================================
// GET/SET
//======================================================

int Inimigo::getChanceEsquiva() const
{
    return chanceEsquiva;
}

void Inimigo::setChanceEsquiva(int chance)
{
    if (chance < 0) chance = 0;
    if (chance > 100) chance = 100;

    chanceEsquiva = chance;
}

//======================================================
// SOBRESCRITA DE DANO (ESQUIVA)
//======================================================

void Inimigo::receberDano(int dano)
{
    int roll = rand() % 100;

    if (roll < chanceEsquiva)
    {
        cout << nome << " desviou do ataque!" << endl;
        return;
    }

    Personagem::receberDano(dano);
}

//======================================================
// ATAQUE
//======================================================

void Inimigo::atacar(Personagem& alvo)
{
    int dano = ataque - alvo.getDefesa();

    if (dano < 1)
        dano = 1;

    cout << endl;
    cout << nome << " atacou o jogador!" << endl;
    cout << "Dano causado: " << dano << endl;

    alvo.receberDano(dano);
}

//======================================================
// HABILIDADE (BASE)
//======================================================

void Inimigo::usarHabilidade()
{
    cout << nome << " não possui habilidade especial definida." << endl;
}

//======================================================
// STATUS
//======================================================

void Inimigo::exibirStatus() const
{
    cout << endl;
    cout << "====== INIMIGO ======" << endl;
    cout << "Nome: " << nome << endl;
    cout << "Nivel: " << nivel << endl;
    cout << "Vida: " << vidaAtual << "/" << vidaMaxima << endl;
    cout << "Ataque: " << ataque << endl;
    cout << "Defesa: " << defesa << endl;
    cout << "Esquiva: " << chanceEsquiva << "%" << endl;
    cout << "=====================" << endl;
}