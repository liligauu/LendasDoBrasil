#pragma once

#include "Inimigo.h"

//======================================================
// Classe: Saci
// Inimigo escalável por fase
//======================================================

class Saci : public Inimigo
{
public:

    Saci(int fase);

    void atacar(Personagem& alvo) override;

    void usarHabilidade() override;
};