#include "MulaSemCabeca.h"

#include <iostream>
#include <cstdlib>

using namespace std;

//======================================================
// CONSTRUTOR
//======================================================

MulaSemCabeca::MulaSemCabeca(int fase)
    : Inimigo(
        "MulaSemCabeca",
        1 + fase,
        80 + (fase * 10),
        15 + (fase * 3),
        5 + (fase * 1)
      )
{
    chanceEsquiva = 25;
}

//======================================================
// ATAQUE ESPECIAL
//======================================================

void MulaSemCabeca::atacar(Personagem& alvo)
{
    int dano = ataque;

    int critico = rand() % 100;

    if (critico < 10)
    {
        dano *= 2;
        cout << "CRÍTICO DA MULA!" << endl;
    }

    cout << endl;
    cout << "Mula usou ataque de chamas!" << endl;
    cout << "Dano causado: " << dano << endl;

    alvo.receberDano(dano);
}

//======================================================
// HABILIDADE
//======================================================

void MulaSemCabeca::usarHabilidade()
{
    cout << "Galope infernal aumenta velocidade!" << endl;
}