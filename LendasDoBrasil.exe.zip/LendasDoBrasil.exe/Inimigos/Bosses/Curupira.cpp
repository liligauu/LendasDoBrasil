#include "Curupira.h"

#include <iostream>

using namespace std;

Curupira::Curupira(int fase)
    : Boss(
        "Curupira",
        1 + fase,
        150 + (fase * 15),
        25 + (fase * 4),
        10 + (fase * 2),
        2
      )
{
}

void Curupira::usarHabilidade()
{
    cout << "Curupira confunde o jogador na floresta!" << endl;
}