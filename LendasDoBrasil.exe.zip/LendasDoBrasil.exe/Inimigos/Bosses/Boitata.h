#pragma once

#include "Boss.h"

//======================================================
// Boss: Boitatá
//======================================================

class Boitata : public Boss
{
public:
    Boitata(int fase);

    void usarHabilidade() override;
};