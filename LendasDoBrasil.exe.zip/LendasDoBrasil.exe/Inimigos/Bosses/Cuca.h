#pragma once

#include "Boss.h"

//======================================================
// Boss: Cuca
//======================================================

class Cuca : public Boss
{
public:
    Cuca(int fase);

    void usarHabilidade() override;
};