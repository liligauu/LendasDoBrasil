#pragma once

#include "Boss.h"

//======================================================
// Boss: Curupira
//======================================================

class Curupira : public Boss
{
public:
    Curupira(int fase);

    void usarHabilidade() override;
};