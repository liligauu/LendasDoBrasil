#include "Boitata.h"

#include <iostream>

using namespace std;

Boitata::Boitata(int fase)
    : Boss(
        "Boitata",
        5 + fase,
        250 + (fase * 40),
        30 + (fase * 7),
        15 + (fase * 4),
        3
      )
{
}

void Boitata::usarHabilidade()
{
    cout << "Boitatá libera fogo em área!" << endl;
}