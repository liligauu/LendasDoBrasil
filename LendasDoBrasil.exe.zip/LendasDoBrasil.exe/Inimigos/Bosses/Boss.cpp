#include "Boss.h"

#include <iostream>
#include <string>

using namespace std;

Boss::Boss(string nome, int nivel, int vida, int ataque, int defesa, int mult)
    : Inimigo(nome, nivel, vida, ataque, defesa),
      multiplicadorDano(mult)
{
    chanceEsquiva = 15;
}

Boss::~Boss() {}

void Boss::atacar(Personagem& alvo)
{
    int dano = (ataque * multiplicadorDano) - alvo.getDefesa();

    if (dano < 1)
        dano = 1;

    cout << "\n" << nome << " usa ataque de boss!" << endl;
    cout << "Dano massivo: " << dano << endl;

    alvo.receberDano(dano);
}