#include "Cuca.h"

#include <iostream>

using namespace std;

Cuca::Cuca(int fase)
    : Boss(
        "Cuca",
        5 + fase,
        250 + (fase * 40),
        30 + (fase * 7),
        15 + (fase * 4),
        3
      )
{
}

void Cuca::usarHabilidade()
{
    cout << "Cuca assusta o jogador com medo profundo!" << endl;
}