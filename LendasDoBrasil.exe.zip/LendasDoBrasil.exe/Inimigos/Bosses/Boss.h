#pragma once

#include <string>
#include "../Inimigo.h"
#include "../../Personagem/Personagem.h"

using std::string;

class Boss : public Inimigo
{
protected:
    int multiplicadorDano;

public:
    Boss(string nome, int nivel, int vida, int ataque, int defesa, int mult);

    virtual ~Boss();

    void atacar(Personagem& alvo) override;
};