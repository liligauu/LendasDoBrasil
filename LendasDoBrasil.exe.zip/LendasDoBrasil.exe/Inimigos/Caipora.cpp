#include "Caipora.h"

#include <iostream>
#include <cstdlib>

using namespace std;

//======================================================
// CONSTRUTOR
//======================================================

Caipora::Caipora(int fase)
    : Inimigo(
        "Caipora",
        1 + fase,
        85 + (fase * 10),
        14 + (fase * 3),
        8 + (fase * 1)
      )
{
    chanceEsquiva = 15;
}

//======================================================
// ATAQUE ESPECIAL
//======================================================

void Caipora::atacar(Personagem& alvo)
{
    int dano = ataque;

    int critico = rand() % 100;

    if (critico < 10)
    {
        dano *= 2;
        cout << "CRÍTICO DO CAIPORA!" << endl;
    }

    cout << endl;
    cout << "Caipora protege a floresta e ataca!!" << endl;
    cout << "Dano causado: " << dano << endl;

    alvo.receberDano(dano);
}

//======================================================
// HABILIDADE
//======================================================

void Caipora::usarHabilidade()
{
    cout << "Caipora confunde o inimigo na floresta!" << endl;
    cout << "O jogador pode errar ataques mais facilmente!" << endl;
}