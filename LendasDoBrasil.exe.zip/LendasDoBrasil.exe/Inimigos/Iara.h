#pragma once

#include "Inimigo.h"

//======================================================
// Classe: Iara (Sereia)
// Inimigo escalável por fase
//======================================================

class Iara : public Inimigo
{
public:

    Iara(int fase);

    void atacar(Personagem& alvo) override;

    void usarHabilidade() override;
};