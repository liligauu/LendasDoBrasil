#include "Saci.h"

#include <iostream>
#include <cstdlib>

using namespace std;

//======================================================
// CONSTRUTOR
//======================================================

Saci::Saci(int fase)
    : Inimigo(
        "Saci",
        1 + fase,
        80 + (fase * 10),
        15 + (fase * 3),
        5 + (fase * 2)
      )
{
    chanceEsquiva = 10;
}

//======================================================
// ATAQUE ESPECIAL
//======================================================

void Saci::atacar(Personagem& alvo)
{
    int dano = ataque;

    int critico = rand() % 100;

    if (critico < 10)
    {
        dano *= 2;
        cout << "CRÍTICO DO SACI!" << endl;
    }

    cout << endl;
    cout << "Saci usou Redemoinho!" << endl;
    cout << "Dano causado: " << dano << endl;

    alvo.receberDano(dano);
}

//======================================================
// HABILIDADE
//======================================================

void Saci::usarHabilidade()
{
    cout << "Saci confunde o jogador com o redemoinho!" << endl;
}