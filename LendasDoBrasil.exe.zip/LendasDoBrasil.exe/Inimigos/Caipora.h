#pragma once

#include "Inimigo.h"

//======================================================
// Classe: Caipora
// Guardião da floresta
// Defesa alta e controle
//======================================================

class Caipora : public Inimigo
{
public:

    Caipora(int fase);

    void atacar(Personagem& alvo) override;

    void usarHabilidade() override;
};