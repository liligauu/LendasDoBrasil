#pragma once

#include "Inimigo.h"

//======================================================
// Classe: Mula sem cabeça
// Inimigo escalável por fase
//======================================================

class MulaSemCabeca : public Inimigo
{
public:

    MulaSemCabeca(int fase);

    void atacar(Personagem& alvo) override;

    void usarHabilidade() override;
};