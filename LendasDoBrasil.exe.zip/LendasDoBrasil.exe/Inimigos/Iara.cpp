#include "Iara.h"

#include <iostream>
#include <cstdlib>

using namespace std;

//======================================================
// CONSTRUTOR
//======================================================

Iara::Iara(int fase)
    : Inimigo(
        "Iara",
        1 + fase,
        70 + (fase * 8),
        18 + (fase * 2),
        6 + (fase * 1)
      )
{
    chanceEsquiva = 25;
}

//======================================================
// ATAQUE
//======================================================

void Iara::atacar(Personagem& alvo)
{
    int dano = ataque;

    int critico = rand() % 100;

    if (critico < 10)
    {
        dano *= 2;
        cout << "CRÍTICO DA IARA!" << endl;
    }

    cout << endl;
    cout << "Iara usou Ondas!" << endl;
    cout << "Dano causado: " << dano << endl;

    alvo.receberDano(dano);
}

//======================================================
// HABILIDADE ESPECIAL
//======================================================

void Iara::usarHabilidade()
{
    cout << "\nIara tenta encantar o jogador..." << endl;
    cout << "O próximo ataque pode falhar!" << endl;
}