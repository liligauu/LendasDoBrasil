#pragma once

#include "../Personagem/Personagem.h"

//======================================================
// Classe: Inimigo
//
// Classe base de todos os monstros do jogo.
//======================================================

class Inimigo : public Personagem
{
protected:

    int chanceEsquiva;

public:

    Inimigo();

    Inimigo(string nome, int nivel, int vidaMaxima, int ataque, int defesa);

    virtual ~Inimigo();

    int getChanceEsquiva() const;
    void setChanceEsquiva(int chance);

    void receberDano(int dano) override;

    void atacar(Personagem& alvo) override;

    void usarHabilidade() override;

    void exibirStatus() const override;
};