#include "Lobisomem.h"

#include <iostream>
#include <cstdlib>

using namespace std;

//======================================================
// CONSTRUTOR
//======================================================

Lobisomem::Lobisomem(int fase)
    : Inimigo(
        "Lobisomem",
        1 + fase,
        90 + (fase * 5),
        12 + (fase * 4),
        6 + (fase * 2)
      )
{
    chanceEsquiva = 15;
}

//======================================================
// ATAQUE
//======================================================

void Lobisomem::atacar(Personagem& alvo)
{
    int dano = ataque;

    int critico = rand() % 100;

    if (critico < 10)
    {
        dano *= 2;
        cout << "CRÍTICO DO LOBISOMEM!" << endl;
    }

    cout << endl;
    cout << "Lobisomem ataca com fúria selvagem!" << endl;
    cout << "Dano causado: " << dano << endl;

    alvo.receberDano(dano);
}

//======================================================
// HABILIDADE
//======================================================

void Lobisomem::usarHabilidade()
{
    cout << "Lobisomem entra em fúria!" << endl;
    cout << "Ataque aumenta temporariamente!" << endl;
    ataque = ataque + 10;
}