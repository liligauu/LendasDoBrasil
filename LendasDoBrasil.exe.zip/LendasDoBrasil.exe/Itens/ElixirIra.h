#pragma once

#include "Item.h"
#include "../Personagem/Personagem.h"

//======================================================
// Elixir da Ira
// Aumenta o ataque do personagem em 20%.
// Efeito TEMPORÁRIO: dura apenas a batalha atual.
// A reversão do bônus é feita pela Batalha2, que guarda
// o ataque original do jogador antes do combate e o
// restaura ao final (vitória, derrota ou fuga).
//======================================================

class ElixirIra : public Item
{
private:
    double percentual; // 0.2 = 20%

public:
    ElixirIra(double percentual = 0.2);

    void usar(Personagem& alvo) override;
};
