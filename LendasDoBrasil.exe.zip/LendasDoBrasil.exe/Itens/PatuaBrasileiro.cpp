#include "PatuaBrasileiro.h"

#include <iostream>

using namespace std;

PatuaBrasileiro::PatuaBrasileiro()
    : Item("Patuá Brasileiro")
{
}

void PatuaBrasileiro::usar(Personagem& alvo)
{
    // O Patuá não tem efeito ao ser "usado" manualmente -
    // ele protege passivamente enquanto estiver no inventário.
    // A Batalha2 o consome automaticamente no momento certo.
    cout << endl;
    cout << alvo.getNome() << " sente o Patuá Brasileiro pulsar de energia..." << endl;
    cout << "Ele protege sozinho, no momento certo. Guarde-o com cuidado!" << endl;
}
