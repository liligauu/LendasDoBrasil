#include "ElixirIra.h"

#include <iostream>

using namespace std;

ElixirIra::ElixirIra(double percentual)
    : Item("Elixir da Ira"),
      percentual(percentual)
{
}

void ElixirIra::usar(Personagem& alvo)
{
    int bonus = static_cast<int>(alvo.getAtaque() * percentual);

    if (bonus < 1)
        bonus = 1;

    cout << endl;
    cout << alvo.getNome() << " bebeu o Elixir da Ira!" << endl;
    cout << "O ataque aumentou em " << bonus << " pontos (20%) ate o fim da batalha!" << endl;

    alvo.setAtaque(alvo.getAtaque() + bonus);

    cout << "Ataque atual: " << alvo.getAtaque() << endl;
}
