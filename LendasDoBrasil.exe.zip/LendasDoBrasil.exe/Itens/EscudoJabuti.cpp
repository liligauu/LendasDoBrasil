#include "EscudoJabuti.h"

#include <iostream>

using namespace std;

EscudoJabuti::EscudoJabuti(int aumentoDefesa)
    : Item("Escudo de Casco de Jabuti"),
      aumentoDefesa(aumentoDefesa)
{
}

void EscudoJabuti::usar(Personagem& alvo)
{
    cout << endl;
    cout << alvo.getNome() << " equipou o Escudo de Casco de Jabuti!" << endl;
    cout << "Defesa aumentou em " << aumentoDefesa << " pontos permanentemente!" << endl;

    alvo.setDefesa(alvo.getDefesa() + aumentoDefesa);

    cout << "Defesa atual: " << alvo.getDefesa() << endl;
}
