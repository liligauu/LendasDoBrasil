#pragma once

#include "Item.h"
#include "../Personagem/Personagem.h"

//======================================================
// Escudo de Casco de Jabuti
// Aumenta permanentemente a defesa do personagem.
//======================================================

class EscudoJabuti : public Item
{
private:
    int aumentoDefesa;

public:
    EscudoJabuti(int aumentoDefesa = 8);

    void usar(Personagem& alvo) override;
};
