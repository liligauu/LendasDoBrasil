#include "Item.h"

Item::Item(string nome)
{
    this->nome = nome;
}

Item::~Item()
{
}

string Item::getNome() const
{
    return nome;
}