#pragma once

#include "Item.h"
#include "../Personagem/Personagem.h"

//======================================================
// Flauta da Iara
// Encanta o inimigo, fazendo-o perder o próximo turno.
//
// Como Item::usar(Personagem&) não tem acesso direto à
// batalha, o efeito é sinalizado através de uma flag
// estática que a Batalha2 consulta imediatamente após
// o jogador usar o item. A flag é resetada a cada leitura.
//======================================================

class FlautaIara : public Item
{
private:
    static bool inimigoAtordoado;

public:
    FlautaIara();

    void usar(Personagem& alvo) override;

    // Consultado pela Batalha2 após o uso do item.
    // Retorna true uma única vez (consome o efeito) e
    // já reseta a flag internamente.
    static bool consumirAtordoamento();
};
