#pragma once

#include "Item.h"
#include "../Personagem/Personagem.h"

//======================================================
// Patuá Brasileiro
// Item passivo: protege o jogador da morte uma única vez.
//
// Não é usado manualmente pelo menu de inventário (usar()
// apenas informa isso, caso o jogador tente). O efeito real
// é checado pela Batalha2 sempre que o jogador receberia o
// golpe fatal: se houver um Patuá no inventário, ele é
// consumido (Inventario::removerItem) e o jogador é revivido
// com uma porção da vida máxima, em vez de ser derrotado.
//======================================================

class PatuaBrasileiro : public Item
{
public:
    PatuaBrasileiro();

    void usar(Personagem& alvo) override;
};
