#pragma once

#include <string>

using namespace std;

class Personagem;

//======================================================
// Classe base de todos os itens
//======================================================

class Item
{
protected:
    string nome;

public:
    Item(string nome);
    virtual ~Item();

    string getNome() const;

    virtual void usar(Personagem& alvo) = 0;
};