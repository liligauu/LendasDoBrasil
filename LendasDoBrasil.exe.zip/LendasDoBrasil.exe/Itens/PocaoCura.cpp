#include "PocaoCura.h"

PocaoCura::PocaoCura()
    : Item("Poção de Cura")
{
}

void PocaoCura::usar(Personagem& alvo)
{
    int cura = (alvo.getVidaMaxima()/2);

    cout << alvo.getNome() << " usou poção de cura!" << endl;
    cout << "Curou " << cura << " de vida!" << endl;

    alvo.curar(cura);
}