#pragma once

#include "Item.h"
#include "../Personagem/Personagem.h"

//======================================================
// Poção de cura baseada em porcentagem da vida
//======================================================

class PocaoCura : public Item{
private:

public:
    PocaoCura();

    void usar(Personagem& alvo) override;
};