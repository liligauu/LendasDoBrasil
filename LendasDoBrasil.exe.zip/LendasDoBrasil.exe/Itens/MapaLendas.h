#pragma once

#include "Item.h"
#include "../Personagem/Personagem.h"

//======================================================
// Mapa das Lendas
// Revela tesouros próximos: garante que o próximo
// inimigo derrotado droppe um item, ignorando a chance
// aleatória normal de loot.
//
// Assim como a Flauta da Iara, sinaliza o efeito através
// de uma flag estática consultada pelo sistema de loot
// (SistemaLoot2) no momento da vitória.
//======================================================

class MapaLendas : public Item
{
private:
    static bool lootGarantido;

public:
    MapaLendas();

    void usar(Personagem& alvo) override;

    // Consultado pelo SistemaLoot2 ao gerar o loot da vitória.
    // Retorna true uma única vez (consome o efeito).
    static bool consumirLootGarantido();
};
