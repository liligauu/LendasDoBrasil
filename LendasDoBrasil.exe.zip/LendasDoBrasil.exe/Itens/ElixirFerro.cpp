#include "ElixirFerro.h"

#include <iostream>

using namespace std;

ElixirFerro::ElixirFerro(int aumentoVida)
    : Item("Elixir de Ferro"),
      aumentoVida(aumentoVida)
{
}

void ElixirFerro::usar(Personagem& alvo)
{
    // Só eleva o teto de vida máxima.
    // setVidaMaxima já existe em Personagem e não altera a vida atual
    // quando o novo máximo é maior, então o requisito é respeitado
    // sem precisar modificar a classe Personagem.
    int novoMaximo = alvo.getVidaMaxima() + aumentoVida;

    cout << endl;
    cout << alvo.getNome() << " bebeu o Elixir de Ferro!" << endl;
    cout << "Vida máxima aumentou em " << aumentoVida << " pontos!" << endl;

    alvo.setVidaMaxima(novoMaximo);

    cout << "Nova vida máxima: " << alvo.getVidaMaxima() << endl;
}
