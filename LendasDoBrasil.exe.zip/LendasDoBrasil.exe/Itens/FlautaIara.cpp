#include "FlautaIara.h"

#include <iostream>

using namespace std;

bool FlautaIara::inimigoAtordoado = false;

FlautaIara::FlautaIara()
    : Item("Flauta da Iara")
{
}

void FlautaIara::usar(Personagem& alvo)
{
    // O parâmetro "alvo" aqui não é usado para dano/cura;
    // o efeito real (atordoar o inimigo) é sinalizado pela
    // flag estática, lida pela Batalha2.
    (void)alvo;

    cout << endl;
    cout << "Uma melodia encantadora ecoa pela floresta..." << endl;
    cout << "O inimigo fica hipnotizado pela Flauta da Iara e perderá o próximo turno!" << endl;

    inimigoAtordoado = true;
}

bool FlautaIara::consumirAtordoamento()
{
    bool valor = inimigoAtordoado;
    inimigoAtordoado = false;
    return valor;
}
