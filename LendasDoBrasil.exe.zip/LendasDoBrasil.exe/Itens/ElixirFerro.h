#pragma once

#include "Item.h"
#include "../Personagem/Personagem.h"

//======================================================
// Elixir de Ferro
// Aumenta permanentemente a vida máxima do personagem.
// (não cura a vida atual, apenas eleva o teto de vida)
//======================================================

class ElixirFerro : public Item
{
private:
    int aumentoVida;

public:
    ElixirFerro(int aumentoVida = 30);

    void usar(Personagem& alvo) override;
};
