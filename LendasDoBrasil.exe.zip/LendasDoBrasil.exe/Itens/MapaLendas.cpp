#include "MapaLendas.h"

#include <iostream>

using namespace std;

bool MapaLendas::lootGarantido = false;

MapaLendas::MapaLendas()
    : Item("Mapa das Lendas")
{
}

void MapaLendas::usar(Personagem& alvo)
{
    (void)alvo;

    cout << endl;
    cout << "Você desenrola o Mapa das Lendas..." << endl;
    cout << "Símbolos antigos revelam onde um tesouro está escondido!" << endl;
    cout << "O próximo inimigo derrotado certamente deixará um item!" << endl;

    lootGarantido = true;
}

bool MapaLendas::consumirLootGarantido()
{
    bool valor = lootGarantido;
    lootGarantido = false;
    return valor;
}
