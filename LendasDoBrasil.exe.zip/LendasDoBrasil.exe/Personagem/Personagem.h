#pragma once

#include <iostream>
#include <string>

#include "../Interfaces/IHabilidade.h"

using namespace std;

//======================================================
// Classe: Personagem
//
// Classe base abstrata de todos os personagens do jogo.
// Jogadores e Inimigos herdam desta classe.
//======================================================

class Personagem : public IHabilidade
{
protected:

    string nome;

    int nivel;

    int experienciaAtual;
    int experienciaNecessaria;

    int vidaAtual;

    int vidaMaxima;

    int ataque;

    int defesa;

    int ouro;

public:

    //=========================
    // CONSTRUTORES
    //=========================

    Personagem();

    Personagem(string nome);

    Personagem(
        string nome,
        int nivel,
        int vidaMaxima,
        int ataque,
        int defesa);

    //=========================
    // DESTRUTOR
    //=========================

    virtual ~Personagem();

    //=========================
    // GETTERS
    //=========================

    string getNome() const;

    int getNivel() const;

    int getExperienciaAtual() const;
    
    int getExperienciaNecessaria() const;

    int getVidaAtual() const;

    int getVidaMaxima() const;

    int getAtaque() const;

    int getDefesa() const;

    int getOuro() const;

    //=========================
    // SETTERS
    //=========================

    void setNome(string nome);

    void setNivel(int nivel);

    void setExperienciaAtual(int experiencia);

    void setExperienciaNecessaria(int experienciaNecessaria);

    void setVidaAtual(int vida);

    void setVidaMaxima(int vida);

    void setAtaque(int ataque);

    void setDefesa(int defesa);

    void setOuro(int ouro);

    //=========================
    // MÉTODOS
    //=========================

    virtual void exibirStatus() const;

    bool estaVivo() const;

    virtual void receberDano(int dano);

    void curar(int valor);

    void ganharExperiencia(int xp);

    void subirNivel();

    //=========================
    // POLIMORFISMO
    //=========================

    virtual void atacar(Personagem& alvo) = 0;

    virtual void usarHabilidade() = 0;
};