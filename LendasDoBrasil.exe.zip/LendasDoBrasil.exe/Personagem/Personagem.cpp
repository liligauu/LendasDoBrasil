#include "Personagem.h"

//======================================================
// CONSTRUTORES
//======================================================

Personagem::Personagem()
    : nome("Desconhecido"),
      nivel(1),
      experienciaAtual(0),
      experienciaNecessaria(100),
      vidaAtual(100),
      vidaMaxima(100),
      ataque(10),
      defesa(5),
      ouro(0)
{

}

Personagem::Personagem(string nome)
    : nome(nome),
      nivel(1),
      experienciaAtual(0),
      experienciaNecessaria(100),
      vidaAtual(100),
      vidaMaxima(100),
      ataque(10),
      defesa(5),
      ouro(0)
{

}

Personagem::Personagem(
    string nome,
    int nivel,
    int vidaMaxima,
    int ataque,
    int defesa)

    : nome(nome),
      experienciaAtual(0),
      experienciaNecessaria(100),
      ouro(0)
{
    setNivel(nivel);

    setVidaMaxima(vidaMaxima);

    vidaAtual = this->vidaMaxima;

    setAtaque(ataque);

    setDefesa(defesa);
}

//======================================================
// DESTRUTOR
//======================================================

Personagem::~Personagem()
{
    cout << nome << " saiu da memória." << endl;
}

//======================================================
// GETTERS
//======================================================

string Personagem::getNome() const
{
    return nome;
}

int Personagem::getNivel() const
{
    return nivel;
}

int Personagem::getExperienciaAtual() const
{
    return experienciaAtual;
}

int Personagem::getExperienciaNecessaria() const
{
    return experienciaNecessaria;
}

int Personagem::getVidaAtual() const
{
    return vidaAtual;
}

int Personagem::getVidaMaxima() const
{
    return vidaMaxima;
}

int Personagem::getAtaque() const
{
    return ataque;
}

int Personagem::getDefesa() const
{
    return defesa;
}

int Personagem::getOuro() const
{
    return ouro;
}

//======================================================
// SETTERS
//======================================================

void Personagem::setNome(string nome)
{
    this->nome = nome;
}

void Personagem::setNivel(int nivel)
{
    if (nivel < 1)
        nivel = 1;

    this->nivel = nivel;
}

void Personagem::setExperienciaAtual(int experienciaAtual)
{
    if (experienciaAtual < 0)
        experienciaAtual = 0;

    this->experienciaAtual = experienciaAtual;
}

void Personagem::setExperienciaNecessaria(int experienciaNecessaria)
{
    if (experienciaNecessaria < 0)
        experienciaNecessaria = 0;

    this->experienciaNecessaria = experienciaNecessaria;
}

void Personagem::setVidaAtual(int vida)
{
    if (vida < 0)
        vida = 0;

    if (vida > vidaMaxima)
        vida = vidaMaxima;

    vidaAtual = vida;
}

void Personagem::setVidaMaxima(int vida)
{
    if (vida < 1)
        vida = 1;

    vidaMaxima = vida;

    if (vidaAtual > vidaMaxima)
        vidaAtual = vidaMaxima;
}

void Personagem::setAtaque(int ataque)
{
    if (ataque < 0)
        ataque = 0;

    this->ataque = ataque;
}

void Personagem::setDefesa(int defesa)
{
    if (defesa < 0)
        defesa = 0;

    this->defesa = defesa;
}

void Personagem::setOuro(int ouro)
{
    if (ouro < 0)
        ouro = 0;

    this->ouro = ouro;
}

//======================================================
// MÉTODOS
//======================================================

void Personagem::exibirStatus() const
{
    cout << "Nome: " << nome << endl;
    cout << "Nível: " << nivel << endl;
    cout << "Vida: " << vidaAtual << "/" << vidaMaxima << endl;
}

bool Personagem::estaVivo() const
{
    return vidaAtual > 0;
}

void Personagem::receberDano(int dano)
{
    if (dano <= 0)
        return;

    int chanceEsquiva = rand() % 100;

    if (chanceEsquiva < 10)
    {
        cout << nome << " desviou do ataque!" << endl;
        return;
    }

    vidaAtual -= dano;

    if (vidaAtual < 0)
        vidaAtual = 0;

    cout << nome << " recebeu " << dano << " de dano!" << endl;
}

void Personagem::curar(int valor)
{
    if (valor <= 0)
        return;

    vidaAtual += valor;

    if (vidaAtual > vidaMaxima)
        vidaAtual = vidaMaxima;
}

void Personagem::ganharExperiencia(int xp)
{
    if (xp <= 0)
        return;

    experienciaAtual += xp;

    while (experienciaAtual >= experienciaNecessaria)
    {
        experienciaAtual -= experienciaNecessaria;
        subirNivel();
    }
}

void Personagem::subirNivel()
{
    nivel++;

    experienciaNecessaria = static_cast<int>(experienciaNecessaria * 1.5);

    vidaMaxima += 40;
    vidaAtual = vidaMaxima;

    ataque = ataque * 1.3;
    defesa = defesa * 1.3;

    cout << endl;
    cout << "========================================" << endl;
    cout << nome << " SUBIU PARA O NÍVEL " << nivel << "!" << endl;
    cout << "XP necessário agora: " << experienciaNecessaria << endl;
    cout << "========================================" << endl;
}