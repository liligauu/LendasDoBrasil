#pragma once

#include "../Inimigos/Inimigo.h"

class FabricaInimigos
{
public:
    static Inimigo* criar(int fase);
};