#pragma once

#include "../Itens/FlautaIara.h"
#include "../Itens/MapaLendas.h"
#include "../Itens/PatuaBrasileiro.h"
#include "../Itens/EscudoJabuti.h"

//======================================================
// Fábrica de Itens Raros
// Itens exclusivos de drop (não vendidos na Loja):
// Flauta da Iara, Mapa das Lendas e Patuá Brasileiro.
//======================================================

class FabricaItemRaro
{
public:
    static Item* criarFlautaIara();
    static Item* criarMapaLendas();
    static Item* criarPatuaBrasileiro();
    static Item* criarEscudoJabuti();
};
