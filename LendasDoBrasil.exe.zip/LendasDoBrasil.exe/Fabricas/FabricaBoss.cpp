#include "FabricaBoss.h"

#include <cstdlib>
#include <ctime>

#include "../Inimigos/Bosses/Boitata.h"
#include "../Inimigos/Bosses/Cuca.h"
#include "../Inimigos/Bosses/Curupira.h"

Inimigo* FabricaBoss::criar(int fase)
{
    srand(time(NULL));

    int r = rand() % 3;

    switch (r)
    {
        case 0: return new Boitata(fase);
        case 1: return new Cuca(fase);
        case 2: return new Curupira(fase);
    }

    return new Cuca(fase);
}