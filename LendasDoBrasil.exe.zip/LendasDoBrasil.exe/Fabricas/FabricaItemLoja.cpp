#include "FabricaItemLoja.h"

Item* FabricaItemLoja::criarElixirFerro()
{
    return new ElixirFerro();
}

Item* FabricaItemLoja::criarElixirIra()
{
    return new ElixirIra();
}
