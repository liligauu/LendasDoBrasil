#include "FabricaInimigos.h"

#include <cstdlib>
#include <ctime>

#include "../Inimigos/MulaSemCabeca.h"
#include "../Inimigos/Iara.h"
#include "../Inimigos/Lobisomem.h"
#include "../Inimigos/Saci.h"
#include "../Inimigos/Caipora.h"

Inimigo* FabricaInimigos::criar(int fase)
{
    srand(time(NULL));

    int r = rand() % 5;

    switch (r)
    {
        case 0: return new MulaSemCabeca(fase);
        case 1: return new Iara(fase);
        case 2: return new Lobisomem(fase);
        case 3: return new Saci(fase);
        case 4: return new Caipora(fase);
    }

    return new Saci(fase);
}