#include "FabricaItem.h"

Item* FabricaItem::criarPocaoCura()
{
    return new PocaoCura();
}