#pragma once

#include "../Itens/PocaoCura.h"

//======================================================
// Factory de Itens
//======================================================

class FabricaItem
{
public:
    static Item* criarPocaoCura();
};