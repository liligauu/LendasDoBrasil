#include "FabricaItemRaro.h"

Item* FabricaItemRaro::criarEscudoJabuti()
{
    return new EscudoJabuti();
}

Item* FabricaItemRaro::criarFlautaIara()
{
    return new FlautaIara();
}

Item* FabricaItemRaro::criarMapaLendas()
{
    return new MapaLendas();
}

Item* FabricaItemRaro::criarPatuaBrasileiro()
{
    return new PatuaBrasileiro();
}
