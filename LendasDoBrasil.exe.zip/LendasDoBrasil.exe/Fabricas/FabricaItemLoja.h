#pragma once

#include "../Itens/ElixirFerro.h"
#include "../Itens/ElixirIra.h"

//======================================================
// Fábrica de Itens da Loja
// (separada de FabricaItem para não alterar o arquivo
// original; segue o mesmo padrão de criação)
//======================================================

class FabricaItemLoja
{
public:
    static Item* criarElixirFerro();
    static Item* criarElixirIra();
};
