#pragma once

#include "../Inimigos/Inimigo.h"

//======================================================
// Fábrica de Bosses
//======================================================

class FabricaBoss
{
public:
    static Inimigo* criar(int fase);
};