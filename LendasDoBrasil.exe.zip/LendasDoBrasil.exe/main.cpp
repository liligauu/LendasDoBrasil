#include <iostream>
#include <ctime>

#include "Batalha/Batalha2.h" 

#include "Fabricas/FabricaItem.h"
#include "Fabricas/FabricaBoss.h"
#include "Fabricas/FabricaInimigos.h"

#include "Inimigos/Caipora.h"
#include "Inimigos/Iara.h"
#include "Inimigos/Lobisomem.h"
#include "Inimigos/MulaSemCabeca.h"
#include "Inimigos/Saci.h"

#include "Inimigos/Bosses/Boitata.h"
#include "Inimigos/Bosses/Curupira.h"
#include "Inimigos/Bosses/Cuca.h"

#include "Jogador/Jogador.h"

#include "Jogo/Jogo.h"

#include "Loja/Loja.h"

#include "Persistencia/SaveManager.h"

#include <limits>

using namespace std;

Jogador criarNovoJogador()
{
    string nome;
    int opClasse;
    int opRaca;

    cout << "\n===== CRIAÇÃO DE PERSONAGEM =====\n";

    cout << "Nome do personagem: ";
    getline(cin, nome);

    cout << "\nEscolha sua classe:\n";
    cout << "1 - Guerreiro\n";
    cout << "2 - Mago\n";
    cout << "3 - Ladrao\n";
    cout << "Opcao: ";
    cin >> opClasse;

    cout << "\nEscolha sua raça:\n";
    cout << "1 - Humano\n";
    cout << "2 - Caboclo\n";
    cout << "3 - Indigena\n";
    cout << "Opcao: ";
    cin >> opRaca;

    Classe classe;
    Raca raca;

    switch (opClasse)
    {
        case 2:
            classe = Classe::Mago;
            break;

        case 3:
            classe = Classe::Ladrao;
            break;

        default:
            classe = Classe::Guerreiro;
    }

    switch (opRaca)
    {
        case 2:
            raca = Raca::Caboclo;
            break;

        case 3:
            raca = Raca::Indigena;
            break;

        default:
            raca = Raca::Humano;
    }

    cout << "\nPersonagem criado com sucesso!\n";

    return Jogador(nome, classe, raca);
}

int main()
{
    srand(time(0));

    int opcao = -1;

    system("cls");   
    //system("clear"); 

    Jogo jogo;
    Jogador jogador = criarNovoJogador();

    cout << "LENDAS DO BRASIL" << endl;

    while (opcao != 0)
    {
        cout << "\n=================================\n";
        cout << "        MENU PRINCIPAL\n";
        cout << "=================================\n";
        cout << "Fase atual: " << jogo.getFase() << endl;
        cout << "=================================\n";
        cout << "1 - Jogar (ver fase)\n";
        cout << "2 - Batalhar\n";
        cout << "3 - Salvar jogo\n";
        cout << "4 - Carregar jogo\n";
        cout << "5 - Status do jogador\n";
        cout << "6 - Inventário\n";
        cout << "7 - Loja\n";
        cout << "0 - Sair\n";
        cout << "=================================\n";
        cout << "Escolha: ";
        cin >> opcao;

        // =========================
        // 1 - MOSTRAR FASE
        // =========================
        if (opcao == 1)
        {
            cout << "\nVocê está na fase " << jogo.getFase() << endl;
            cout << "\nPressione ENTER para continuar...";
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cin.get();
        }

        // =========================
        // 2 - BATALHA
        // =========================
        else if (opcao == 2)
        {
            bool venceu = false;
            Inimigo* inimigo = nullptr;

            // BOSS A CADA 4 FASES
            if (jogo.getFase() % 4 == 0 && jogo.getFase() != 0)
            {
                cout << "\nBOSS APARECEU!\n";

                inimigo = FabricaBoss::criar(jogo.getFase());
            }
            else
            {
                // INIMIGO ALEATÓRIO
                inimigo = FabricaInimigos::criar(jogo.getFase());
            }

            // =========================
            // BATALHA
            // =========================
            venceu = Batalha2::iniciar(jogador, *inimigo);
            
            delete inimigo;

            // =========================
            // PROGRESSÃO
            // =========================
            if (venceu)
            {
                jogo.proximaFase();

                int xp = 100 * jogo.getFase();
                jogador.ganharExperiencia(xp);

                cout << "\nXP ganho: " << xp << endl;
                cout << "\nPressione ENTER para continuar...";
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                cin.get();
            }
            else
            {
                cout << "\nGAME OVER!\n";
                cout << "\nPressione ENTER para continuar...";
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                cin.get();
                break;
            }
        }

        // =========================
        // 3 - SALVAR
        // =========================
        else if (opcao == 3)
        {
            SaveManager::salvar(jogador, jogo);
            cout << "\nPressione ENTER para continuar...";
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cin.get();
        }

        // =========================
        // 4 - CARREGAR
        // =========================
        else if (opcao == 4)
        {
            SaveManager::carregar(jogo, jogador);
            cout << "\nPressione ENTER para continuar...";
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cin.get();
        }

        // =========================
        // 5 - STATUS
        // =========================
        else if (opcao == 5)
        {
            jogador.exibirStatus();
            jogo.mostrarFase();
            cout << "\nPressione ENTER para continuar...";
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cin.get();
        }

        // =========================
        // 6 - Inventario
        // =========================
        else if (opcao == 6)
        {
            jogador.mostrarInventario();
            cout << "\nPressione ENTER para continuar...";
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cin.get();
        }

        // =========================
        // 7 - Loja
        // =========================
        else if (opcao == 7)
        {
            Loja::abrir(jogador);
            cout << "\nPressione ENTER para continuar...";
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cin.get();
        }

        // =========================
        // 0 - SAIR
        // =========================
        else if (opcao == 0)
        {
            cout << "\nSaindo do jogo...\n";
        }

        else
        {
            cout << "\nOpção inválida!\n";
        }
    }

    return 0;
}