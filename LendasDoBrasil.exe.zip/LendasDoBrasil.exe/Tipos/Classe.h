#pragma once

enum class Classe
{
    Guerreiro,
    Mago,
    Ladrao
};