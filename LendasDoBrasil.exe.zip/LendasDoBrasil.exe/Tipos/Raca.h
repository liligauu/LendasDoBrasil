#pragma once

enum class Raca
{
    Humano,
    Indigena,
    Caboclo
};