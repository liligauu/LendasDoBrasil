#include "Jogador.h"

#include <iostream>
#include "../Itens/PocaoCura.h"

using namespace std;

//======================================================
// CONSTRUTORES
//======================================================

Jogador::Jogador()
    : Personagem(),
      classe(Classe::Guerreiro),
      raca(Raca::Humano)
{
    ataque = 20;
    defesa = 10;
}

Jogador::Jogador(string nome, Classe classe, Raca raca)
    : Personagem(nome),
      classe(classe),
      raca(raca)
{
    switch (classe)
    {
        case Classe::Guerreiro:
            ataque = 45;
            defesa = 10;
            break;

        case Classe::Mago:
            ataque = 35;
            defesa = 20;
            break;

        case Classe::Ladrao:
            ataque = 40;
            defesa = 15;
            break;
    }
}

//======================================================
// DESTRUTOR
//======================================================

Jogador::~Jogador()
{
    cout << "Jogador destruído." << endl;
}

//======================================================
// GETTERS
//======================================================

Classe Jogador::getClasse() const
{
    return classe;
}

Raca Jogador::getRaca() const
{
    return raca;
}

//======================================================
// SETTERS
//======================================================

void Jogador::setClasse(Classe classe)
{
    this->classe = classe;
}

void Jogador::setRaca(Raca raca)
{
    this->raca = raca;
}

//======================================================
// POLIMORFISMO
//======================================================

void Jogador::atacar(Personagem& alvo)
{
    int chanceCritico = rand() % 100;

    int dano = ataque - alvo.getDefesa();

    if (chanceCritico < 20)
    {
        dano *= 2;
        cout << "ATAQUE CRÍTICO!" << endl;
    }

    if (dano < 1)
        dano = 1;

    cout << endl;
    cout << "==================================" << endl;
    cout << nome << " atacou o inimigo!" << endl;
    cout << "Dano causado: " << dano << endl;
    cout << "==================================" << endl;

    alvo.receberDano(dano);
}

//======================================================
// STATUS
//======================================================

void Jogador::exibirStatus() const
{
    cout << endl;
    cout << "===================================" << endl;
    cout << "         LENDAS DO BRASIL" << endl;
    cout << "===================================" << endl;

    cout << "Nome.........: " << nome << endl;
    cout << "Classe.......: ";

    switch (classe)
    {
        case Classe::Guerreiro: cout << "Guerreiro"; break;
        case Classe::Mago: cout << "Mago"; break;
        case Classe::Ladrao: cout << "Ladrão"; break;
    }

    cout << endl;

    cout << "Raça.........: ";

    switch (raca)
    {
        case Raca::Humano: cout << "Humano"; break;
        case Raca::Indigena: cout << "Indígena"; break;
        case Raca::Caboclo: cout << "Caboclo"; break;
    }

    cout << endl;

    cout << "Nível........: " << nivel << endl;
    cout << "XP...........: " << experienciaAtual << "/" << experienciaNecessaria << endl;
    cout << "Vida.........: " << vidaAtual << "/" << vidaMaxima << endl;
    cout << "Ataque.......: " << ataque << endl;
    cout << "Defesa.......: " << defesa << endl;
    cout << "Ouro.........: " << ouro << endl;

    cout << "===================================" << endl;
}

void Jogador::usarHabilidade()
{
    cout << endl;
    cout << nome << " usou uma habilidade especial de " ;

    switch (classe)
    {
        case Classe::Guerreiro:
            cout << "Guerreiro: Golpe Forte!" << endl;
            break;

        case Classe::Mago:
            cout << "Mago: Bola de Energia!" << endl;
            break;

        case Classe::Ladrao:
            cout << "Ladrão: Ataque Furtivo!" << endl;
            break;
    }
}

void Jogador::adicionarItem(Item* item)
{
    inventario.adicionar(item);
}

void Jogador::usarItem(int index)
{
    inventario.usar(index, *this);
}

void Jogador::mostrarInventario() const
{
    inventario.listar();
}

void Jogador::ganharOuro(int quantidade)
{
    if (quantidade < 0)
        return;

    ouro += quantidade;
}

bool Jogador::inventarioVazio() const
{
    return inventario.vazio();
}

int Jogador::quantidadeItem(string nome) const
{
    return inventario.quantidadeItem(nome);
}