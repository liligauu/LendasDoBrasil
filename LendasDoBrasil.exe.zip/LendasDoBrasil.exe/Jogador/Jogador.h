#pragma once

#include "../Personagem/Personagem.h"
#include "../Tipos/Classe.h"
#include "../Tipos/Raca.h"
#include "../Itens/Item.h"
#include "../Inventario/Inventario.h"
#include <vector>

#include <string>

using namespace std;

//======================================================
// Classe: Jogador
//
// Representa o personagem controlado pelo usuário.
// Herda de Personagem e implementa ataques e habilidades.
//======================================================

class Jogador : public Personagem
{
private:

    Classe classe;
    Raca raca;

public:

    //=========================
    // CONSTRUTORES
    //=========================

    Jogador();

    Jogador(string nome, Classe classe, Raca raca);
    
    Inventario inventario;

    //=========================
    // DESTRUTOR
    //=========================

    ~Jogador();

    //=========================
    // GETTERS
    //=========================

    Classe getClasse() const;

    Raca getRaca() const;

    //=========================
    // SETTERS
    //=========================

    void setClasse(Classe classe);

    void setRaca(Raca raca);

    //=========================
    // POLIMORFISMO (OBRIGATÓRIO)
    //=========================

    void atacar(Personagem& alvo) override;

    void usarHabilidade() override;

    //=========================
    // MÉTODOS
    //=========================

    void exibirStatus() const override;

    void adicionarItem(Item* item);

    void usarItem(int index);

    void mostrarInventario() const;

    void ganharOuro(int quantidade);

    bool inventarioVazio() const;

    bool carregando = false;

    int quantidadeItem(string nome) const;
};