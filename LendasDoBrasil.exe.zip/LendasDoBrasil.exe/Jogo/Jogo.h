#pragma once

#include <iostream>

using namespace std;

//======================================================
// Classe: Jogo (controla o fluxo do RPG)
//======================================================

class Jogo
{
private:
    int fase;

public:
    Jogo();

    int getFase() const;
    void setFase(int f);
    void proximaFase();
    void mostrarFase() const;
};