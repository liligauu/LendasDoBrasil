#include "Jogo.h"

Jogo::Jogo()
{
    fase = 0;
}

int Jogo::getFase() const
{
    return fase;
}

void Jogo::setFase(int f)
{
        fase = f;
}

void Jogo::proximaFase()
{
    fase++;

    cout << "\n==================================" << endl;
    cout << "FASE " << fase << " DESBLOQUEADA!" << endl;
    cout << "==================================" << endl;
}

void Jogo::mostrarFase() const
{
    cout << "\nFase atual: " << fase << endl;
}