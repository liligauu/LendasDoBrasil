#pragma once

class IHabilidade
{
public:

    virtual void usarHabilidade() = 0;

    virtual ~IHabilidade() = default;
};