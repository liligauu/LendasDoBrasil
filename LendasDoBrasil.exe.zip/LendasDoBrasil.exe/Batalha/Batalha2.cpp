#include "Batalha2.h"
#include "../Loja/Loja.h"
#include "../Loot/SistemaLoot2.h"
#include <limits>
#include <iostream>

using namespace std;

bool Batalha2::iniciar(Jogador& jogador, Inimigo& inimigo)
{
    // Guarda o ataque de entrada na batalha para reverter
    // qualquer bônus temporário do Elixir da Ira ao final,
    // sem precisar alterar Personagem/Jogador.
    int ataqueBase = jogador.getAtaque();

    cout << "\n==================================" << endl;
    cout << "        BATALHA INICIADA!" << endl;
    cout << "==================================" << endl;

    jogador.exibirStatus();
    inimigo.exibirStatus();

    while (jogador.estaVivo() && inimigo.estaVivo())
    {
        int escolha;

        cout << "\n========= SEU TURNO =========\n";

        if (!jogador.inventarioVazio())
        {
            cout << "1 - Atacar\n";
            cout << "2 - Usar Item\n";
            cout << "3 - Ir para a Loja\n";
            cout << "4 - Status do jogador\n";
            cout << "Escolha: ";
            cin >> escolha;
        }
        else
        {
            cout << "📦 Inventário vazio!\n";
            cout << "1 - Atacar\n";
            cout << "3 - Ir para a Loja\n";
            cout << "4 - Status do jogador\n";
            cout << "Escolha: ";
            cin >> escolha;

            if (escolha != 3)
                escolha = 1;
        }

        if (escolha == 1)
        {
            jogador.atacar(inimigo);
        }
        else if (escolha == 2 && !jogador.inventarioVazio())
        {
            jogador.mostrarInventario();

            int item;

            cout << "\nQual item deseja usar? ";
            cin >> item;

            jogador.usarItem(item);

            // Usar item não consome o turno de ataque, mas
            // o inimigo ainda ataca normalmente em seguida,
            // mantendo o mesmo comportamento da Batalha original.
        }
        else if (escolha == 3)
        {
            // Loja não consome o turno: o jogador volta e
            // decide o que fazer antes do inimigo agir.
            Loja::abrir(jogador);
            cout << "\nVocê voltou para a batalha!\n";
            continue;
        }else if(escolha == 4){
            jogador.exibirStatus();
            cout << "\nPressione ENTER para continuar...";
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cin.get();
            cout << "\nVocê voltou para a batalha!\n";
            continue;
        }
        else
        {
            cout << "\nOpção inválida! Você perdeu o turno.\n";
        }

        if (!inimigo.estaVivo())
            break;

        inimigo.atacar(jogador);

        cout << "\n----------------------------------\n";
    }

    // Reverte qualquer bônus temporário de ataque (Elixir da Ira)
    // ganho durante esta batalha, vivo ou morto o jogador.
    jogador.setAtaque(ataqueBase);

    if (jogador.estaVivo())
    {
        cout << "\nVITÓRIA DO JOGADOR!" << endl;

        int baseOuro = 20;
        int bonusNivel = jogador.getNivel() * 5;
        int ouroFinal = baseOuro + bonusNivel + (rand() % 15);

        cout << "\nVocê ganhou " << ouroFinal << " de ouro!" << endl;

        jogador.ganharOuro(ouroFinal);
        SistemaLoot2::gerarLoot(jogador, inimigo);
        return true;
    }
    else
    {
        cout << "\nVOCÊ FOI DERROTADO..." << endl;
        return false;
    }
}
