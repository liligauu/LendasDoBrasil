#pragma once

#include "../Jogador/Jogador.h"
#include "../Inimigos/Inimigo.h"

//======================================================
// Classe: Batalha2
//
// Versão da Batalha original com acesso à Loja durante
// o turno do jogador. Não altera Batalha.cpp/h originais.
//
// Também é responsável por reverter o bônus temporário
// de ataque do Elixir da Ira ao fim do combate, já que
// esse item não modifica Personagem/Jogador.
//======================================================

class Batalha2
{
public:
    static bool iniciar(Jogador& jogador, Inimigo& inimigo);
};
