#pragma once

#include <string>
#include "../Jogador/Jogador.h"
#include "../Jogo/Jogo.h"
#include "../Itens/PocaoCura.h"
#include "../Itens/ElixirFerro.h"
#include "../Itens/ElixirIra.h"
#include "../Fabricas/FabricaItem.h"
#include "../Fabricas/FabricaItemLoja.h"
#include "../Fabricas/FabricaItemRaro.h"

class SaveManager
{
public:
    static void salvar(const Jogador& jogador, const Jogo& jogo);
    static void carregar(Jogo& jogo, Jogador& jogador);
};