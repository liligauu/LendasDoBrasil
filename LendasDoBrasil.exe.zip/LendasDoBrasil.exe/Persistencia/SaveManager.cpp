#include "SaveManager.h"
#include <fstream>
#include <iostream>

using namespace std;

//======================================================
// SALVAR
//======================================================
void SaveManager::salvar(const Jogador& jogador, const Jogo& jogo)
{
    ofstream file("save.txt");

    file << jogador.getNome() << endl;
    file << jogador.getNivel() << endl;
    file << jogador.getExperienciaAtual() << endl;
    file << jogador.getExperienciaNecessaria() << endl;

    file << jogador.getVidaAtual() << endl;
    file << jogador.getVidaMaxima() << endl;

    file << jogador.getAtaque() << endl;
    file << jogador.getDefesa() << endl;
    file << jogador.getOuro() << endl;

    file << jogo.getFase() << endl;

    file << (int)jogador.getClasse() << endl;
    file << (int)jogador.getRaca() << endl;

    file << jogador.quantidadeItem("Poção de Cura") << endl;
    file << jogador.quantidadeItem("Elixir de Ferro") << endl;
    file << jogador.quantidadeItem("Elixir da Ira") << endl;
    file << jogador.quantidadeItem("Escudo de Casco de Jabuti") << endl;
    file << jogador.quantidadeItem("Flauta da Iara") << endl;
    file << jogador.quantidadeItem("Patuá Brasileiro");



    //qtdEscudoJabuti, qtdFlautaIara, qtdPatuaBrasileiro;

    file.close();

    cout << "\nJogo salvo com sucesso!\n";
}

//======================================================
// CARREGAR (VERSÃO CORRIGIDA)
//======================================================
void SaveManager::carregar(Jogo& jogo, Jogador& j){
    ifstream file("save.txt");

    if (!file.is_open())
    {
        cout << "Erro ao abrir save!\n";
        Jogador("Default", Classe::Guerreiro, Raca::Humano);
    }

    string nome;
    int nivel, xp, xpn;
    int vidaAtual, vidaMax;
    int ataque, defesa, ouro, fase;
    int classe, raca;
    int qtdPocaoCura, qtdElixirFerro, qtdElixirIra, qtdEscudoJabuti, qtdFlautaIara, qtdPatuaBrasileiro;

    file >> nome;
    file >> nivel;
    file >> xp;
    file >> xpn;
    file >> vidaAtual;
    file >> vidaMax;
    file >> ataque;
    file >> defesa;
    file >> ouro;
    file >> fase;
    file >> classe;
    file >> raca;
    file >> qtdPocaoCura;
    file >> qtdElixirFerro;
    file >> qtdElixirIra;
    file >> qtdEscudoJabuti;
    file >> qtdFlautaIara;
    file >> qtdPatuaBrasileiro;

    j.~Jogador();
    new (&j) Jogador(nome, (Classe)classe, (Raca)raca);

    j.carregando = true;

    j.setNivel(nivel);
    j.setExperienciaAtual(xp);
    j.setExperienciaNecessaria(xpn);

    j.setVidaMaxima(vidaMax);
    j.setVidaAtual(vidaAtual);

    j.setAtaque(ataque);
    j.setDefesa(defesa);
    j.setOuro(ouro);
    jogo.setFase(fase);

    for (int i = 0; i < qtdPocaoCura; i++){
        j.adicionarItem(new PocaoCura());
    }

    for (int i = 0; i < qtdElixirFerro; i++){
        j.adicionarItem(FabricaItemLoja::criarElixirFerro());
    }

    for (int i = 0; i < qtdElixirIra; i++){
        j.adicionarItem(FabricaItemLoja::criarElixirIra());
    }

    for (int i = 0; i < qtdEscudoJabuti; i++){
        j.adicionarItem(FabricaItemRaro::criarEscudoJabuti());
    }

    for (int i = 0; i < qtdFlautaIara; i++){
        j.adicionarItem(FabricaItemRaro::criarFlautaIara());
    }

    for (int i = 0; i < qtdPatuaBrasileiro; i++){
        j.adicionarItem(FabricaItemRaro::criarPatuaBrasileiro());
    }
    

    j.carregando = false;

    cout << "\nJogo carregado com sucesso!\n";
}