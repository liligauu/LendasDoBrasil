#include "SistemaLoot2.h"

#include "../Itens/PocaoCura.h"
#include "../Itens/MapaLendas.h"
#include "../Itens/FlautaIara.h"
#include "../Itens/PatuaBrasileiro.h"
#include "../Itens/EscudoJabuti.h"
#include "../Fabricas/FabricaItemRaro.h"
#include "../Inimigos/Bosses/Boss.h"

#include <iostream>
#include <cstdlib>

using namespace std;

void SistemaLoot2::gerarLoot(Jogador& jogador, Inimigo& inimigo)
{
    bool ehBoss = dynamic_cast<Boss*>(&inimigo) != nullptr;

    // ----------------------------------------------------
    // Poção de Cura (mesma lógica do SistemaLoot original)
    // ----------------------------------------------------
    bool dropouAlgo = false;

    int chancePocao = rand() % 100;

    if (ehBoss)
    {
        if (chancePocao < 70)
        {
            cout << "🧪 O boss dropou uma Poção de Cura!\n";
            jogador.adicionarItem(new PocaoCura());
            dropouAlgo = true;
        }
    }
    else
    {
        if (chancePocao < 25)
        {
            cout << "🧪 O inimigo dropou uma Poção de Cura!\n";
            jogador.adicionarItem(new PocaoCura());
            dropouAlgo = true;
        }
    }

    // ----------------------------------------------------
    // Itens raros: Mapa das Lendas, Flauta da Iara, Patuá
    // Chances diferentes para boss e inimigo comum.
    // Cada item tem sua própria rolagem independente.
    // ----------------------------------------------------
    int chanceMapa   = rand() % 100;
    int chanceFlauta = rand() % 100;
    int chancePatua  = rand() % 100;
    int chanceEscudo  = rand() % 100;

    int limiteMapa   = ehBoss ? 12 : 6;
    int limiteFlauta = ehBoss ? 8  : 3;
    int limitePatua  = ehBoss ? 8  : 3;
    int limiteEscudo  = ehBoss ? 20 : 8; 

    if (chanceMapa < limiteMapa)
    {
        cout << "📜 O " << (ehBoss ? "boss" : "inimigo") << " dropou um Mapa das Lendas!\n";
        jogador.adicionarItem(FabricaItemRaro::criarMapaLendas());
        dropouAlgo = true;
    }

    if (chanceFlauta < limiteFlauta)
    {
        cout << "🪈 O " << (ehBoss ? "boss" : "inimigo") << " dropou uma Flauta da Iara!\n";
        jogador.adicionarItem(FabricaItemRaro::criarFlautaIara());
        dropouAlgo = true;
    }

    if (chancePatua < limitePatua)
    {
        cout << "🧿 O " << (ehBoss ? "boss" : "inimigo") << " dropou um Patuá Brasileiro!\n";
        jogador.adicionarItem(FabricaItemRaro::criarPatuaBrasileiro());
        dropouAlgo = true;
    }

    if (chanceEscudo < limiteEscudo)
    {
        cout << "🐢 O " << (ehBoss ? "boss" : "inimigo") << " dropou um Escudo Jabuti!\n";
        jogador.adicionarItem(FabricaItemRaro::criarEscudoJabuti());
        dropouAlgo = true;
    }

    // ----------------------------------------------------
    // Mapa das Lendas usado anteriormente: garante loot
    // se a sorte não tiver dado nada nesta vitória.
    // A flag é sempre consumida nesta vitória (o efeito vale
    // só para o próximo inimigo derrotado, não acumula).
    // ----------------------------------------------------
    bool tinhaMapaAtivo = MapaLendas::consumirLootGarantido();

    if (!dropouAlgo && tinhaMapaAtivo)
    {
        cout << "📜 O Mapa das Lendas revelou um tesouro escondido!\n";
        cout << "🧪 Você encontrou uma Poção de Cura garantida!\n";
        jogador.adicionarItem(new PocaoCura());
        dropouAlgo = true;
    }

    if (!dropouAlgo)
    {
        cout << "Nenhum item foi dropado desta vez.\n";
    }
}