#pragma once

#include "../Jogador/Jogador.h"
#include "../Inimigos/Inimigo.h"

//======================================================
// Classe: SistemaLoot2
//
// Versão expandida do SistemaLoot original (que não é
// alterado). Mantém o drop de Poção de Cura já existente
// e adiciona o drop dos itens raros: Mapa das Lendas,
// Flauta da Iara e Patuá Brasileiro.
//
// Também respeita o efeito do Mapa das Lendas: se o
// jogador tiver usado um Mapa antes desta vitória, o loot
// desta batalha é garantido, ignorando a chance aleatória.
//======================================================

class SistemaLoot2
{
public:
    static void gerarLoot(Jogador& jogador, Inimigo& inimigo);
};
