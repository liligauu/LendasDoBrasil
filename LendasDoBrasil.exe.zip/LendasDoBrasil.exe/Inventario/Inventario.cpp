#include "Inventario.h"

Inventario::Inventario()
{
}

Inventario::~Inventario()
{
    for (Item* item : itens)
    {
        delete item;
    }

    itens.clear();
}

void Inventario::adicionar(Item* item)
{
    auto it = quantidades.find(item->getNome());

    if (it == quantidades.end())
    {
        itens.push_back(item);
        quantidades[item->getNome()] = 1;
    }
    else
    {
        it->second++;
        delete item; // descarta o objeto repetido
    }
}

void Inventario::usar(int index, Personagem& alvo)
{
    if (index < 0 || index >= itens.size())
        return;

    Item* item = itens[index];

    item->usar(alvo);

    quantidades[item->getNome()]--;

    if (quantidades[item->getNome()] == 0)
    {
        quantidades.erase(item->getNome());

        delete item;
        itens.erase(itens.begin() + index);
    }
}

void Inventario::listar() const
{
    cout << "\n===== INVENTÁRIO =====\n";

    if (itens.empty())
    {
        cout << "\nInventário vazio.\n";
        return;
    }

    for (size_t i = 0; i < itens.size(); i++)
    {
        cout << i << " - "
             << itens[i]->getNome()
             << ": "
             << quantidades.at(itens[i]->getNome())
             << endl;
    }

    cout << "======================\n";
}

bool Inventario::vazio() const
{
    return itens.empty();
}

int Inventario::quantidadeItem(const string& nome) const
{
    auto it = quantidades.find(nome);

    if (it == quantidades.end())
        return 0;

    return it->second;
}