#pragma once

#include <vector>
#include <iostream>
#include <map>
#include <string>

#include "../Itens/Item.h"
#include "../Personagem/Personagem.h"

using namespace std;

//======================================================
// Classe: Inventario
//======================================================

class Inventario
{
private:
    vector<Item*> itens;
    map<string, int> quantidades;

public:
    Inventario();
    ~Inventario();

    Inventario(const Inventario&) = delete;
    Inventario& operator=(const Inventario&) = delete;

    void adicionar(Item* item);
    void usar(int index, Personagem& alvo);

    int quantidadeItem(const string& nome) const;

    void listar() const;

    bool vazio() const;
};