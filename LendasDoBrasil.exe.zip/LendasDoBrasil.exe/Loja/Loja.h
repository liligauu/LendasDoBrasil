#pragma once

#include "../Jogador/Jogador.h"

//======================================================
// Classe: Loja
//
// Permite ao jogador comprar itens usando o ouro
// dropado por inimigos e bosses.
//======================================================

class Loja
{
public:
    // Abre o menu da loja e processa as compras do jogador.
    // Retorna o controle quando o jogador escolhe sair (opção 0).
    static void abrir(Jogador& jogador);

private:
    static const int PRECO_ELIXIR_FERRO = 50;
    static const int PRECO_ELIXIR_IRA   = 40;

    static void exibirMenu(const Jogador& jogador);
    static void comprarElixirFerro(Jogador& jogador);
    static void comprarElixirIra(Jogador& jogador);
};
