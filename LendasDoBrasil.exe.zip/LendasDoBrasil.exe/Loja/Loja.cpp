#include "Loja.h"
#include "../Fabricas/FabricaItemLoja.h"

#include <iostream>

using namespace std;

//======================================================
// MENU
//======================================================

void Loja::exibirMenu(const Jogador& jogador)
{
    cout << "\n==================================" << endl;
    cout << "              LOJA" << endl;
    cout << "==================================" << endl;
    cout << "Seu ouro: " << jogador.getOuro() << endl;
    cout << "----------------------------------" << endl;
    cout << "1 - Elixir de Ferro (+30 vida maxima) - " << PRECO_ELIXIR_FERRO << " de ouro" << endl;
    cout << "2 - Elixir da Ira (+20% de ataque, dura a batalha) - " << PRECO_ELIXIR_IRA << " de ouro" << endl;
    cout << "0 - Sair da loja" << endl;
    cout << "==================================" << endl;
    cout << "Escolha: ";
}

//======================================================
// COMPRAS
//======================================================

void Loja::comprarElixirFerro(Jogador& jogador)
{
    if (jogador.getOuro() < PRECO_ELIXIR_FERRO)
    {
        cout << "\nOuro insuficiente para comprar o Elixir de Ferro!" << endl;
        return;
    }

    jogador.setOuro(jogador.getOuro() - PRECO_ELIXIR_FERRO);
    jogador.adicionarItem(FabricaItemLoja::criarElixirFerro());

    cout << "\nVocê comprou um Elixir de Ferro!" << endl;
}

void Loja::comprarElixirIra(Jogador& jogador)
{
    if (jogador.getOuro() < PRECO_ELIXIR_IRA)
    {
        cout << "\nOuro insuficiente para comprar o Elixir da Ira!" << endl;
        return;
    }

    jogador.setOuro(jogador.getOuro() - PRECO_ELIXIR_IRA);
    jogador.adicionarItem(FabricaItemLoja::criarElixirIra());

    cout << "\nVocê comprou um Elixir da Ira!" << endl;
}

//======================================================
// ABRIR LOJA
//======================================================

void Loja::abrir(Jogador& jogador)
{
    int opcao = -1;

    while (opcao != 0)
    {
        exibirMenu(jogador);
        cin >> opcao;

        if (opcao == 1)
        {
            comprarElixirFerro(jogador);
        }
        else if (opcao == 2)
        {
            comprarElixirIra(jogador);
        }
        else if (opcao == 0)
        {
            cout << "\nSaindo da loja..." << endl;
        }
        else
        {
            cout << "\nOpção inválida!" << endl;
        }
    }
}
